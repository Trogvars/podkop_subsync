Podkop subscription sync installer for OpenWrt 25.12.x.

Example:
  chmod +x install-podkop-sub-sync.sh
  ./install-podkop-sub-sync.sh \
    --url 'https://YOUR/SUBSCRIPTION' \
    --interval 86400 \
    --exclude RU

Repeat --exclude for multiple countries.
Existing /etc/config/podkop-sub-sync is preserved on re-install.
Executable files are backed up under /root/podkop-sub-sync-backup-YYYYMMDD-HHMMSS.

Useful commands:
  uci show podkop-sub-sync
  /usr/bin/podkop-sub-sync
  /etc/init.d/podkop-sub-sync restart
  ubus call service list '{"name":"podkop-sub-sync"}'
  logread | grep podkop-sub-sync | tail -100
